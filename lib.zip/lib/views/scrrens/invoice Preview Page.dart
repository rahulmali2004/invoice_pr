import 'package:flutter/material.dart';

class InvoicePreviewPage extends StatefulWidget {
  const InvoicePreviewPage({Key? key}) : super(key: key);

  @override
  State<InvoicePreviewPage> createState() => _InvoicePreviewPageState();
}

class _InvoicePreviewPageState extends State<InvoicePreviewPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
