import 'package:flutter/material.dart';

class MyRoutes{
  static String homepage = "/";
  static String SplashScreenPage = "splashscrren";
  static String ProductDetailPage = "ProductDetailPage";
  static String FavouriteProductsPage = "FavouriteProductsPage";
  static String CartPage = "CartPage";
  static String CustomerInfoPage = "CustomerInfoPage";
  static String  InvoicePreviewPage= "InvoicePreviewPage";
}